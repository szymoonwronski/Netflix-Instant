window.addEventListener('load', event => {
    main()
});
function main() {
    function a(s) {
        return new Promise(r => {
            if (document.querySelector(s)) return r(document.querySelector(s));
            const o = new MutationObserver(() => {
                if (document.querySelector(s)) {
                    r(document.querySelector(s));
                }
            });
            o.observe(document.body, {
                childList: true,
                subtree: true
            })
        })
    }
    a('[data-uia="player-skip-recap"]').then(x => {
        x.click()
        main()
    });
    a('[data-uia="player-skip-intro"]').then(x => {
        x.click()
        main()
    });
    a('[data-uia="next-episode-seamless-button-draining"]').then(x => {
        x.click()
        main()
    });
    a('[data-uia="next-episode-seamless-button"]').then(x => {
        x.click()
        main()
    })
}
